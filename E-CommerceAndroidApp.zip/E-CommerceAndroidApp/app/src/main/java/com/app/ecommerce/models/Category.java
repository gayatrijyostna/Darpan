package com.app.ecommerce.models;

public class Category {

    private String category_id;
    private String category_name;
    private String category_image;
    private String product_count;

    public String getCategory_id() {
        return category_id;
    }

    public String getCategory_name() {
        return category_name;
    }

    public String getCategory_image() {
        return category_image;
    }

    public String getProduct_count() {
        return product_count;
    }

}
